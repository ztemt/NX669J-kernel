# Berlin Driver Porting Guide

## Driver source file prepare
1. Move driver source code to $KERNEL_SRC/drivers/input/touchscree/
2. Change $KERNEL_SRC/drivers/input/touchscree/Makefile
Add this line to the Makefile
```
obj-y += goodix_berlin_driver/
```
3. Change $KERNEL_SRC/drivers/input/touchscree/Kconfg
Add this line to the Kconfig
```
source "drivers/input/touchscreen/goodix_berlin_driver/Kconfig"
```

## Add device declaration in the board devicetree
Please add Goodix touch device declaration info in the board devicetree, you can refer the Appendix goodix-ts-i2c-dtsi or goodix-ts-spi-dtsi  to see how to set deivce properties.

## Build driver
When build kernel you will see the following promt to let you confirm how to build the driver. This driver support built-in kernel or build as modules.

Follwing is a example of built-in kernel with IIC interface.

```
Goodix berlin touchscreen (TOUCHSCREEN_GOODIX_BRL) [Y/n/m/?] (NEW) y
  support I2C bus connection (TOUCHSCREEN_GOODIX_BRL_I2C) [N/m/y/?] (NEW) n
  support SPI bus connection (TOUCHSCREEN_GOODIX_BRL_SPI) [N/m/y/?] (NEW) y
  Goodix debug tools support (TOUCHSCREEN_GOODIX_TS_TOOLS) [Y/n/m/?] (NEW) y
  Goodix gesture support (TOUCHSCREEN_GOODIX_TS_GESTURE) [Y/n/m/?] (NEW) y
```
Or, if you use SPI interface and build the driver as kernel modules, you can select like this

```
Goodix berlin touchscreen (TOUCHSCREEN_GOODIX_BRL) [Y/n/m/?] (NEW) m
  support I2C bus connection (TOUCHSCREEN_GOODIX_BRL_I2C) [N/m/?] (NEW) n
  support SPI bus connection (TOUCHSCREEN_GOODIX_BRL_SPI) [N/m/?] (NEW) m
  Goodix debug tools support (TOUCHSCREEN_GOODIX_TS_TOOLS) [M/n/?] (NEW) m
  Goodix gesture support (TOUCHSCREEN_GOODIX_TS_GESTURE) [M/n/?] (NEW) m
```

**About the Kconfig options:**

TOUCHSCREEN_GOODIX_BRL is required.

TOUCHSCREEN_GOODIX_BRL_I2C and TOUCHSCREEN_GOODIX_BRL_SPI must select one depends on you touch controller bus interface.

TOUCHSCREEN_GOODIX_TS_TOOLS is required for debug and touch panel test, we strongly suggest you select this.

TOUCHSCREEN_GOODIX_TS_GESTURE is for support gesture related operation,  select as you needed.

## Modify driver code
- Print more debug log
You can get more debug log through define this macro in the `goodix_ts_core.h`,
```
#define CONFIG_GOODIX_DEBUG
```

## Firmware and IC config update
If you want support firmware/config upgrade when kernel boot-up.
Please copy the `goodix_firmware.bin` and `goodix_cfg_group.bin` files into target board filesystem path that are accesiable by kernel `request_firmware()` function. The typical path are `/etc/firmware/` and `/vendor/firmware/`. The firmware file name are defined in the driver you can change it as you wanted.

```
#define TS_DEFAULT_FIRMWARE "goodix_firmware.bin"
#define TS_DEFAULT_CFG_BIN  "goodix_cfg_group.bin"
```

## Appendix

**goodix-ts-i2c-dtsi**

```
devicetree binding for Goodix i2c touchdriver
Required properties:
- compatible: device & driver matching.
	* for berlin series touch device, souch as "goodix,gt9897"

- reg: i2c client address, value can be 0x14 or 0x5d. please refer to datasheet.
- goodix,reset-gpio: reset gpio.
- goodix,irq-gpio: interrupt gpio. 
- goodix,irq-flags: irq trigger type config, value should be:
	       1 - rising edge,
	       2 - falling edge,
	       4 - high level,
	       5 - low level.
- goodix,panel-max-x: max resolution of x direction.
- goodix,panel-max-y: max resolution of y direction.
- goodix,panel-max-w: panel max width value.
- goodix,panel-max-p: pen device max pressure value.

Optional properties:
- goodix,avdd-name: set name of regulator.
- avdd-supply: power supply for the touch device.
  example of regulator:
	goodix,avdd-name = "avdd";
	avdd-supply = <&pm8916_l15>;
- iovdd-supply: power supply for digital io circuit
  example of regulator:
	goodix,iovdd-name = "iovdd";
	iovdd-supply = <&pm8916_l16>;
- goodix,pen-enable: set this property if you want support stylus.
	goodix,pen-enable;
Example 1:
goodix-berlin@5d {
	compatible = "goodix,gt9897";
	reg = <0x5d>;
	goodix,reset-gpio = <&msm_gpio 12 0x0>;
	goodix,irq-gpio = <&msm_gpio 13 0x2800>;
	goodix,irq-flags = <2>; /* 1:trigger rising, 2:trigger falling;*/
	goodix,panel-max-x = <720>;
	goodix,panel-max-y = <1280>;
	goodix,panel-max-w = <255>;
};

Example 2:
goodix-berlin@5d {
	compatible = "goodix,gt9896";
	goodix,avdd-name = "avdd";
	avdd-supply = <&pm8916_l15>;
	goodix,iovdd-name = "iovdd";
	iovdd-supply = <&pm8916_l16>;

	reg = <0x5d>;
	goodix,reset-gpio = <&msm_gpio 12 0x0>;
	goodix,irq-gpio = <&msm_gpio 13 0x2800>;
	goodix,irq-flags = <2>; /* 1:trigger rising, 2:trigger falling;*/
	goodix,panel-max-x = <720>;
	goodix,panel-max-y = <1280>;
	goodix,panel-max-w = <255>;
	goodix,panel-max-p = <4096>; /* max pressure that pen device supported */
	goodix,pen-enable; /* support active stylus device*/
};
```

**goodix-ts-spi-dtsi**

```
devicetree binding for Goodix spi touchdriver

Required properties:
- compatible: device & driver matching.
	* for berlin series touch device, souch as "goodix,gt9897T"

- spi-max-frequency: set spi transfer speed.
- reg: depend on CS gpio.
- goodix,reset-gpio: reset gpio.
- goodix,irq-gpio: interrupt gpio.
- goodix,irq-flags: irq trigger type config, value should be:
	       1 - rising edge,
	       2 - falling edge,
	       4 - high level,
	       5 - low level.
- goodix,panel-max-x: max resolution of x direction.
- goodix,panel-max-y: max resolution of y direction.
- goodix,panel-max-w: panel max width value.
- goodix,panel-max-p: pen device max pressure value.

Optional properties:
- goodix,avdd-name: set name of regulator.
- avdd-supply: power supply for the touch device.
  example of regulator:
	goodix,avdd-name = "avdd";
	avdd-supply = <&pm8916_l15>;
- iovdd-supply: power supply for digital io circuit
  example of regulator:
	goodix,iovdd-name = "iovdd";
	iovdd-supply = <&pm8916_l16>;
- goodix,pen-enable: set this property if you want support stylus.
	goodix,pen-enable;
Example 1:
goodix-berlin@0 {
	compatible = "goodix,gt9897";
	reg = <0>;
	spi-max-frequency = <1000000>;
	goodix,reset-gpio = <&msm_gpio 12 0x0>;
	goodix,irq-gpio = <&msm_gpio 13 0x2800>;
	goodix,irq-flags = <2>; /* 1:trigger rising, 2:trigger falling;*/
	goodix,panel-max-x = <720>;
	goodix,panel-max-y = <1280>;
	goodix,panel-max-w = <255>;
};

Example 2:
goodix-berlin@0 {
	compatible = "goodix,gt9897";
	reg = <0>;
	spi-max-frequency = <1000000>;

	goodix,avdd-name = "avdd";
	avdd-supply = <&pm8916_l15>;
	goodix,iovdd-name = "iovdd";
	iovdd-supply = <&pm8916_l16>;

	goodix,reset-gpio = <&msm_gpio 12 0x0>;
	goodix,irq-gpio = <&msm_gpio 13 0x2800>;
	goodix,irq-flags = <2>; /* 1:trigger rising, 2:trigger falling;*/
	goodix,panel-max-x = <720>;
	goodix,panel-max-y = <1280>;
	goodix,panel-max-w = <255>;
	goodix,panel-max-p = <4096>; /* max pressure that pen device supported */
	goodix,pen-enable; /* support active stylus device*/
};
```

